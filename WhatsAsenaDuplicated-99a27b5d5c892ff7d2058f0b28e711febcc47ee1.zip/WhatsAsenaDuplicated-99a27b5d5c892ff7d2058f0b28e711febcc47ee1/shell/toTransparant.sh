ffmpeg -i "{INPUT}" -vf chromakey={COLOR} "{OUTPUT}"
